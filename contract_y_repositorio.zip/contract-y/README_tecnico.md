# Contract Y -- Repositorio Tecnico

Smart contracts universais baseados na Superposicao de Papeis (Teoria Y).

## Axioma

Todo sistema que persiste e triadico.
Polo (-1): ancora -- quem ancora a transacao
Polo  (0): GOV API -- sistema de aceite
Polo (+1): expansao -- quem recebe e expande

## Stack

- Solana / Anchor framework (Rust)
- GOV API (Gov.br + Receita Federal)
- Pix Bridge (Bacen API)
- $HCN SPL Token (governanca)

## Instalar

```bash
# Pre-requisitos
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
sh -c "$(curl -sSfL https://release.solana.com/stable/install)"
npm install -g @coral-xyz/anchor-cli

# Instalar dependencias
yarn install

# Compilar
anchor build

# Testar em localnet
anchor test

# Deploy em devnet
solana config set --url devnet
anchor deploy
```

## Estrutura

```
contract-y/
  programs/contract_y/src/lib.rs   <- smart contract (Rust)
  tests/contract_y.ts              <- testes (TypeScript)
  scripts/gov_api_simulado.ts      <- GOV API simulado
  README_tecnico.md
  Anchor.toml
  package.json
```

## Estados do Contrato

INDEFINIDO (-1) -> PENDENTE (0) -> ACEITO (+1)
                               -> NEUTRO (+1)
                               -> RECUSADO (+1)
INDEFINIDO | PENDENTE -> LIMBO (polo 0 nao fechou)

## Instrucoes

1. criar()      -- cria contrato em superposicao
2. submeter()   -- polo (-1) submete prova de entrega
3. aceitar()    -- polo (+1) confirma, Pix e disparado
4. neutralizar()-- aceite com condicoes
5. recusar()    -- recusa com motivo registrado
6. expirar()    -- anti-LIMBO: qualquer um chama apos prazo
7. confirmar_pix() -- Pix Bridge confirma liquidacao on-chain

## Token $HCN

Contrato: 8GgWhpVrvHA3v43AUaqRnFgC2FcUS86Bo7DMmEoygGLY
Rede: Solana Mainnet / Pump.fun
Autor: Henrique Campos Novo, Porto Alegre, 2026

## Licenca

CC BY 4.0 -- Henrique Campos Novo, 2026
github.com/henriquecamposnovo-HCN/teoria-y
