/**
 * GOV API Simulado -- para desenvolvimento e testes
 * Teoria Y / Contract Y -- Henrique Campos Novo, 2026
 */

export async function aceitePreview(params: {
  entidade_neg1: { tipo: "CPF" | "CNPJ"; numero: string };
  entidade_pos1: { tipo: "CPF" | "CNPJ"; numero: string };
  tipo_contrato: string;
}) {
  const classificadores: Record<string, { classificador: string; aliquota_bps: number }> = {
    servico_digital:   { classificador: "3.1.1.01", aliquota_bps: 500  },
    compra_venda:      { classificador: "3.1.2.01", aliquota_bps: 925  },
    energia_p2p:       { classificador: "3.3.1.01", aliquota_bps: 1200 },
    licitacao_publica: { classificador: "4.2.1.01", aliquota_bps: 0    },
  };
  const fiscal = classificadores[params.tipo_contrato] || { classificador: "3.9.9.99", aliquota_bps: 925 };
  return {
    aceito: true,
    ...fiscal,
    prazo_maximo_horas: 720,
    token_aceite: `jwt_simulado_${Date.now()}_gov`,
  };
}

export async function dispararPix(params: {
  chave_pix_destino: string;
  valor_centavos: number;
  contrato_pda: string;
}) {
  console.log(`[PIX BRIDGE] R$ ${(params.valor_centavos/100).toFixed(2)} -> ${params.chave_pix_destino}`);
  return {
    hash_pix: `pix_e2e_${Date.now()}_bacen`,
    liquidado_em: Date.now(),
  };
}
