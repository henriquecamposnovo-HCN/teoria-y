# Contract Y

**Smart Contracts Universais via Superposicao de Papeis**

> Teoria Y | $HCN | Solana + Pix + GOV API
> Henrique Campos Novo -- Porto Alegre, Brasil, 2026

---

## O Principio

O Contract Y resolve o problema fundamental dos smart contracts atuais:
a necessidade de definir as partes antes da execucao.

```
Contrato tradicional:  define as partes antes -- papel fixo -- LIMBO
Contract Y:            define os papeis (-1, 0, +1) -- papel dinamico -- sem LIMBO
```

**Superposicao de Papeis:** qualquer entidade (CPF, CNPJ, GOV) ocupa
qualquer polo dependendo da transacao. O papel colapsa no momento
certo via o polo (0) do sistema de aceite (GOV API).

```
(-1) = quem ancora    -- CPF comprador, CNPJ insumos, GOV arrecadacao
 (0) = quem medeia    -- GOV API aceite, NF-e oraculo, Pix Bridge
(+1) = quem expande   -- CNPJ vendedor, CPF prestador, GOV infraestrutura
```

---

## Arquitetura

```
┌─────────────────────────────────────────────────────┐
│                    CONTRACT Y                        │
│                                                      │
│  Entidade (-1) ──► GOV API aceite ──► Entidade (+1) │
│       │                  │                  │        │
│    ancora             medeia             expande     │
│       │                  │                  │        │
│    Solana ◄──── Pix Bridge ◄──── NF-e/Hash/IOT      │
└─────────────────────────────────────────────────────┘
```

### Quatro Camadas

| Camada | Tecnologia | Status |
|--------|------------|--------|
| Identidade / Aceite | Gov.br API + Receita Federal | API existe -- endpoint papel a criar |
| Contrato | Solana + Anchor (Rust) | **A construir -- este repositorio** |
| Liquidacao | API Pix / Bacen | Existe -- Pix Bridge a criar |
| Oraculo | Hash / NF-e SEFAZ / IOT | Parcial -- hash e dupla assinatura prontos |

---

## Instalacao

### Pre-requisitos

```bash
# Rust
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh

# Solana CLI
sh -c "$(curl -sSfL https://release.solana.com/v1.18.0/install)"

# Anchor
cargo install --git https://github.com/coral-xyz/anchor avm --locked
avm install 0.29.0 && avm use 0.29.0

# Node / Yarn
npm install -g yarn
```

### Setup

```bash
git clone https://github.com/henriquecamposnovo-HCN/contract-y
cd contract-y
yarn install

# Configurar carteira Solana (sua carteira: GcM8R4...)
solana config set --url devnet
solana config set --keypair ~/.config/solana/id.json
```

### Build e Deploy (devnet)

```bash
# Build
anchor build

# Deploy em devnet (gratis)
anchor deploy --provider.cluster devnet

# Executar testes
anchor test
```

---

## Estados do Contrato

```
INDEFINIDO (-1)  proposta criada, superposicao de papeis
     |
     | submeter(proof)
     |
PENDENTE   (0)   GOV API validando -- tem prazo maximo
     |
     |-- executar(aceito=true)  --> ACEITO  (+1)  Pix liquidado
     |-- executar(CONDICAO:...) --> NEUTRO  (+1)  aprovado com condicoes
     |-- executar(aceito=false) --> RECUSADO(+1)  motivo registrado
     |
     |-- expirar() [apos prazo] --> LIMBO  (colapso 0) auditoria
```

---

## Uso do SDK

```typescript
import { ContractYSDK, OraculoY } from "@contract-y/sdk";
import { Connection, PublicKey } from "@solana/web3.js";

const sdk = new ContractYSDK(
  new Connection("https://api.devnet.solana.com"),
  new PublicKey("CONTRACT_Y_PROGRAM_ID")
);

// 1. GOV API valida papeis -- aceite previo
const contrato = await sdk.criar({
  poloNeg1: { tipo: "CPF", numero: "123.456.789-00", pubkey: cpfWallet, polo: "-1" },
  poloPosUm: { tipo: "CNPJ", numero: "12.345.678/0001-00", pubkey: cnpjWallet, polo: "+1" },
  valorBrlReais: 1000.00,
  condicao: "hash_digital",
  prazoDias: 30,
  // ... retornado pelo GOV API
  classificadorFiscal: "3.1.1.01",
  aliquotaImposto: 9.25,
  tokenAceiteGov: "jwt.gov.token",
}, pagador);

// 2. Entrega confirmada -- oraculo colapsa o papel
const proof = OraculoY.hashDigital("arquivo_entregue.pdf");
await sdk.submeter(contrato.pda, proof, pagador);

// 3. GOV aceita + Pix liquida automaticamente
const resultado = await sdk.executar(contrato.pda, "cnpj@chave.pix", 1000.00, 9.25);

console.log("Estado:", resultado.estado); // ACEITO
console.log("Hash Pix:", resultado.hashPix);
// Debito (-1) + Credito (+1) = 0
```

---

## Casos de Uso

| Caso | Polo (-1) | Polo (0) GOV | Polo (+1) | Oraculo |
|------|-----------|--------------|-----------|---------|
| Servico digital | CPF comprador | GOV API + hash | CPF/CNPJ prestador | Hash SHA256 |
| Produto fisico | CPF/CNPJ comprador | GOV API + NF-e | CNPJ vendedor | NF-e SEFAZ |
| Energia P2P | CPF solar (excesso) | GOV API + medicao | CPF sem painel | IOT medidor |
| Licitacao publica | CNPJ executor | GOV API + marcos | GOV contratante | Dupla assinatura |
| Governanca DAO | Holders $HCN | Protocolo Solana | Comunidade | Voto on-chain |

---

## Composibilidade -- Y dentro de Y

```typescript
// Financiamento em cascata
const contrato1 = await sdk.criar({ poloNeg1: banco, poloPosUm: empresa, ... });
const contrato2 = await sdk.criar({ poloNeg1: empresa, poloPosUm: freelancer, ... });
// contrato1.pda pode ser polo (-1) de contrato2
// cada contrato tem seu proprio aceite GOV
// cada liquidacao Pix e independente
```

---

## Token $HCN

O token $HCN e o polo (0) financeiro do protocolo.

```
Contrato:  8GgWhpVrvHA3v43AUaqRnFgC2FcUS86Bo7DMmEoygGLY
Rede:      Solana Mainnet
Supply:    1.000.000.000 (fixo)
Pump.fun:  https://pump.fun/coin/8GgW...gGLY
```

Usado para: governanca DAO, micropagamentos de taxas do protocolo,
incentivos para desenvolvedores.

---

## Roadmap

| Fase | Periodo | Entregavel |
|------|---------|------------|
| MVP devnet | Semana 1-4 | Smart contract + testes + oraculo hash |
| Integracao Pix | Mes 2-3 | Pix Bridge + primeiro contrato real |
| Oraculo NF-e | Mes 4-6 | NF-e SEFAZ + imposto automatico |
| Protocolo aberto | Mes 7-12 | SDK open source + composibilidade |
| DAO $HCN | Ano 2 | Governanca on-chain |

---

## Licenca

CC BY 4.0 -- Henrique Campos Novo, Porto Alegre, Brasil, 2026

```
H . C . N = sempre
Debito (-1) + Credito (+1) = 0
O polo (0) colapsa o papel no momento certo.
```

github.com/henriquecamposnovo-HCN/teoria-y | branch: aplicacoes-y
